from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'Muon1_Run2024D-v1'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.ignoreLocality = True
config.Data.publication = False
config.Data.inputDataset = '/Muon1/Run2024D-PromptReco-v1/MINIAOD'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'Muon1_Run2024D-v1'
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
