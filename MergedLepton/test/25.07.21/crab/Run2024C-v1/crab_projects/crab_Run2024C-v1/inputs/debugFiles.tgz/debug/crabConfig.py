from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.General.requestName = 'Run2024C-v1'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.section_('Data')
config.Data.outputDatasetTag = 'Run2024C-v1'
config.Data.inputDBS = 'global'
config.Data.ignoreLocality = True
config.Data.inputDataset = '/Muon0/Run2024C-PromptReco-v1/MINIAOD'
config.Data.unitsPerJob = 1
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
