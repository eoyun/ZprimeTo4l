from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Muon1_Run2024I-v2'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.outputDatasetTag = 'Muon1_Run2024I-v2'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.inputDataset = '/Muon1/Run2024I-PromptReco-v2/MINIAOD'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
