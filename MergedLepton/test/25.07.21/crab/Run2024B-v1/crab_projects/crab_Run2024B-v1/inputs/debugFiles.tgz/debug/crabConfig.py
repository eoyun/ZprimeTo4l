from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'Run2024B-v1'
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.publication = False
config.Data.inputDataset = '/Muon0/Run2024B-PromptReco-v1/MINIAOD'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'Run2024B-v1'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
