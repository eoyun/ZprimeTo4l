from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Muon1_Run2024H-v1'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.section_('Data')
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/Muon1/Run2024H-PromptReco-v1/MINIAOD'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.ignoreLocality = True
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'Muon1_Run2024H-v1'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
