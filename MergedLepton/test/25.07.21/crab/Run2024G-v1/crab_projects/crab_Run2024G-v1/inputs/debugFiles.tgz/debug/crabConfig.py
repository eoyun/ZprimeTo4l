from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Run2024G-v1'
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'Run2024G-v1'
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/Muon0/Run2024G-PromptReco-v1/MINIAOD'
config.Data.splitting = 'FileBased'
config.Data.ignoreLocality = True
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
