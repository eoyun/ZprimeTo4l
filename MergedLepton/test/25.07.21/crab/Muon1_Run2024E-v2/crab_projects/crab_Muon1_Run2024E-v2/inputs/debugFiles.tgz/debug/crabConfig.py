from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'Muon1_Run2024E-v2'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.section_('Data')
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'Muon1_Run2024E-v2'
config.Data.inputDataset = '/Muon1/Run2024E-PromptReco-v2/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.splitting = 'FileBased'
config.Data.ignoreLocality = True
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
