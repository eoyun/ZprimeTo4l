from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon10_2024G'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ParkingSingleMuon10/Run2024G-PromptReco-v1/MINIAOD'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'ParkingSingleMuon10_2024G'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
