from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.General.requestName = 'ParkingSingleMuon4_2024B'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon4/Run2024B-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 1
config.Data.ignoreLocality = True
config.Data.outputDatasetTag = 'ParkingSingleMuon4_2024B'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
