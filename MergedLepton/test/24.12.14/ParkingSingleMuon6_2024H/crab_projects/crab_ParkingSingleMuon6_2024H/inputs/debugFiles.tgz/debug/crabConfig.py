from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon6_2024H'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.outputDatasetTag = 'ParkingSingleMuon6_2024H'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon6/Run2024H-PromptReco-v1/MINIAOD'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
