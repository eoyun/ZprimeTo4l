from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon7_2024C'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.inputDataset = '/ParkingSingleMuon7/Run2024C-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.outputDatasetTag = 'ParkingSingleMuon7_2024C'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
