from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ParkingSingleMuon4_2024F'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon4/Run2024F-PromptReco-v1/MINIAOD'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDBS = 'global'
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'ParkingSingleMuon4_2024F'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
