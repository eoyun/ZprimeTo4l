from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon6_2024I'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'ParkingSingleMuon6_2024I'
config.Data.ignoreLocality = True
config.Data.inputDataset = '/ParkingSingleMuon6/Run2024I-PromptReco-v2/MINIAOD'
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
