from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ParkingSingleMuon6_2024F'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.outputDatasetTag = 'ParkingSingleMuon6_2024F'
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon6/Run2024F-PromptReco-v1/MINIAOD'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
