from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'ParkingSingleMuon11_2024H'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'ParkingSingleMuon11_2024H'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.inputDataset = '/ParkingSingleMuon11/Run2024H-PromptReco-v1/MINIAOD'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
