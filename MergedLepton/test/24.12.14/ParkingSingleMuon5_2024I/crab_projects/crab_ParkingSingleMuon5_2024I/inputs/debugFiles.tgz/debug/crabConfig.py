from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'ParkingSingleMuon5_2024I'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ParkingSingleMuon5/Run2024I-PromptReco-v2/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.outputDatasetTag = 'ParkingSingleMuon5_2024I'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
