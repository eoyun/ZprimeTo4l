from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'ParkingSingleMuon9_2024H'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.outputDatasetTag = 'ParkingSingleMuon9_2024H'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.ignoreLocality = True
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ParkingSingleMuon9/Run2024H-PromptReco-v1/MINIAOD'
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
