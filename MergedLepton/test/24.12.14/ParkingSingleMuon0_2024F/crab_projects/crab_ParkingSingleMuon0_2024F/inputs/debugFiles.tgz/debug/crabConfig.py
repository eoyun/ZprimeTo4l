from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ParkingSingleMuon0_2024F'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outputDatasetTag = 'ParkingSingleMuon0_2024F'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.ignoreLocality = True
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon0/Run2024F-PromptReco-v1/MINIAOD'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
