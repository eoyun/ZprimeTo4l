from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'HToAATo4L_H2000A5_22'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDImageMC_run3_cfg.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'phys03'
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/HToAATo4L_H2000A5_TuneCP5_13p6TeV-pythia8/yeo-Run3Summer22_MiniAODv4_v1-5443ed9e0a49f9c5d5f0b2fff4804347/USER'
config.Data.outputDatasetTag = 'HToAATo4L_H2000A5_22'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
