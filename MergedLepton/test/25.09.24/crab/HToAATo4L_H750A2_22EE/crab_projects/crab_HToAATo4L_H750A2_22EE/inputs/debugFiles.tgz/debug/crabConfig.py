from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'HToAATo4L_H750A2_22EE'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDImageMC_run3_cfg.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'HToAATo4L_H750A2_22EE'
config.Data.publication = False
config.Data.inputDBS = 'phys03'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/HToAATo4L_H750A2_TuneCP5_13p6TeV-pythia8/yeo-Run3Summer22EE_MiniAODv4_v1-8d987a117c9c64189fa569ace8eb11af/USER'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
