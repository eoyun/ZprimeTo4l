from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'HToAATo4L_H2000A50_22EE'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDImageMC_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'phys03'
config.Data.ignoreLocality = True
config.Data.publication = False
config.Data.inputDataset = '/HToAATo4L_H2000A50_TuneCP5_13p6TeV-pythia8/yeo-Run3Summer22EE_MiniAODv4_v1-8d987a117c9c64189fa569ace8eb11af/USER'
config.Data.outputDatasetTag = 'HToAATo4L_H2000A50_22EE'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
