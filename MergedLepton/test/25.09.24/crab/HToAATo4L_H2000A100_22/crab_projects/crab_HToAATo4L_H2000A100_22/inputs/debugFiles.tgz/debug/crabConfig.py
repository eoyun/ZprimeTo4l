from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'HToAATo4L_H2000A100_22'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDImageMC_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDataset = '/HToAATo4L_H2000A100_TuneCP5_13p6TeV-pythia8/yeo-Run3Summer22_MiniAODv4_v1-5443ed9e0a49f9c5d5f0b2fff4804347/USER'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.outputDatasetTag = 'HToAATo4L_H2000A100_22'
config.Data.inputDBS = 'phys03'
config.Data.splitting = 'FileBased'
config.Data.ignoreLocality = True
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
