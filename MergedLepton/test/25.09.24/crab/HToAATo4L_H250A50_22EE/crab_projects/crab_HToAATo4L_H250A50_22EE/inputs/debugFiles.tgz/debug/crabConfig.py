from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'HToAATo4L_H250A50_22EE'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDImageMC_run3_cfg.py'
config.section_('Data')
config.Data.outputDatasetTag = 'HToAATo4L_H250A50_22EE'
config.Data.inputDataset = '/HToAATo4L_H250A50_TuneCP5_13p6TeV-pythia8/yeo-Run3Summer22EE_MiniAODv4_v1-8d987a117c9c64189fa569ace8eb11af/USER'
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDBS = 'phys03'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.ignoreLocality = True
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
