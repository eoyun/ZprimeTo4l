from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'ParkingSingleMuon3_2024C'
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/ParkingSingleMuon3/Run2024C-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'ParkingSingleMuon3_2024C'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
