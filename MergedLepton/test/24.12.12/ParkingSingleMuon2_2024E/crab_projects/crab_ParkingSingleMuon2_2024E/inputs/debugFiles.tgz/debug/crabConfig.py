from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon2_2024E'
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon2/Run2024E-PromptReco-v2/MINIAOD'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'ParkingSingleMuon2_2024E'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
