from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ParkingSingleMuon2_2024D'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/ParkingSingleMuon2/Run2024D-PromptReco-v1/MINIAOD'
config.Data.outputDatasetTag = 'ParkingSingleMuon2_2024D'
config.Data.ignoreLocality = True
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
