from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon5_2024H'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.ignoreLocality = True
config.Data.outputDatasetTag = 'ParkingSingleMuon5_2024H'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/ParkingSingleMuon5/Run2024H-PromptReco-v1/MINIAOD'
config.Data.publication = False
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
