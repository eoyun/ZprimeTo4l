from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ParkingSingleMuon5_2024E'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.outputDatasetTag = 'ParkingSingleMuon5_2024E'
config.Data.inputDataset = '/ParkingSingleMuon5/Run2024E-PromptReco-v2/MINIAOD'
config.Data.ignoreLocality = True
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
