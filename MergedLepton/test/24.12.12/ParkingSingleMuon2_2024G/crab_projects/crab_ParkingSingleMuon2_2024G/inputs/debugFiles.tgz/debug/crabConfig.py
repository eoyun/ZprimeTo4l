from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'ParkingSingleMuon2_2024G'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.outputDatasetTag = 'ParkingSingleMuon2_2024G'
config.Data.inputDBS = 'global'
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ParkingSingleMuon2/Run2024G-PromptReco-v1/MINIAOD'
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
