from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'ParkingSingleMuon0_2024G'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.Data.inputDataset = '/ParkingSingleMuon0/Run2024G-PromptReco-v1/MINIAOD'
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.outputDatasetTag = 'ParkingSingleMuon0_2024G'
config.Data.ignoreLocality = True
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
