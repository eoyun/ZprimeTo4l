from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon0_2024D'
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.ignoreLocality = True
config.Data.outputDatasetTag = 'ParkingSingleMuon0_2024D'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/ParkingSingleMuon0/Run2024D-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
