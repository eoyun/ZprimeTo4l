from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = 'ParkingSingleMuon11_2024I'
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'ParkingSingleMuon11_2024I'
config.Data.ignoreLocality = True
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDataset = '/ParkingSingleMuon11/Run2024I-PromptReco-v2/MINIAOD'
config.Data.unitsPerJob = 1
config.Data.publication = False
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
