from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon1_2024I'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'ParkingSingleMuon1_2024I'
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/ParkingSingleMuon1/Run2024I-PromptReco-v2/MINIAOD'
config.Data.ignoreLocality = True
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
