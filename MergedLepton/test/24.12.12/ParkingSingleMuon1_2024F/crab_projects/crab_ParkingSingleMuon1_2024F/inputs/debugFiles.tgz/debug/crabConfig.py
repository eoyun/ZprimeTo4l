from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'ParkingSingleMuon1_2024F'
config.General.workArea = 'crab_projects'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDataset = '/ParkingSingleMuon1/Run2024F-PromptReco-v1/MINIAOD'
config.Data.publication = False
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'ParkingSingleMuon1_2024F'
config.Data.ignoreLocality = True
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
