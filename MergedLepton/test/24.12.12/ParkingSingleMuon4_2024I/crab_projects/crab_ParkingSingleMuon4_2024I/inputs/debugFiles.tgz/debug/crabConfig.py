from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = 'ParkingSingleMuon4_2024I'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'ParkingSingleMuon4_2024I'
config.Data.publication = False
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDataset = '/ParkingSingleMuon4/Run2024I-PromptReco-v2/MINIAOD'
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
