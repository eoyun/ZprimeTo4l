from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'crab_projects'
config.General.requestName = 'ParkingSingleMuon7_2024E'
config.section_('JobType')
config.JobType.psetName = 'runMergedLeptonIDJpsiAnalyzerData_run3_2024_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.publication = False
config.Data.ignoreLocality = True
config.Data.inputDataset = '/ParkingSingleMuon7/Run2024E-PromptReco-v2/MINIAOD'
config.Data.outputDatasetTag = 'ParkingSingleMuon7_2024E'
config.Data.inputDBS = 'global'
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
