from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.requestName = 'Muon0_Run2024E-v1'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.section_('Data')
config.Data.ignoreLocality = True
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.inputDataset = '/Muon0/Run2024E-PromptReco-v1/MINIAOD'
config.Data.splitting = 'FileBased'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.outputDatasetTag = 'Muon0_Run2024E-v1'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
