from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'Muon0_Run2024I-v1'
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.publication = False
config.Data.outputDatasetTag = 'Muon0_Run2024I-v1'
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.inputDataset = '/Muon0/Run2024I-PromptReco-v1/MINIAOD'
config.Data.ignoreLocality = True
config.Data.outLFNDirBase = '/store/user/yeo/'
config.section_('Site')
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.storageSite = 'T3_KR_KNU'
config.section_('User')
config.section_('Debug')
