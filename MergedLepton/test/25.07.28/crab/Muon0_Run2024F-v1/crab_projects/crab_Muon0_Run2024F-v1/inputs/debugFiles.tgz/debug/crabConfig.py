from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = 'Muon0_Run2024F-v1'
config.General.workArea = 'crab_projects'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.unitsPerJob = 1
config.Data.outputDatasetTag = 'Muon0_Run2024F-v1'
config.Data.publication = False
config.Data.inputDataset = '/Muon0/Run2024F-PromptReco-v1/MINIAOD'
config.Data.inputDBS = 'global'
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.ignoreLocality = True
config.Data.splitting = 'FileBased'
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
