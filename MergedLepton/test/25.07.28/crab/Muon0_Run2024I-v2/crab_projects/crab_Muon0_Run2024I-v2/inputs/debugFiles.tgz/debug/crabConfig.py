from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.requestName = 'Muon0_Run2024I-v2'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'runMuonJpsi_run3_cfg.py'
config.section_('Data')
config.Data.inputDataset = '/Muon0/Run2024I-PromptReco-v2/MINIAOD'
config.Data.outputDatasetTag = 'Muon0_Run2024I-v2'
config.Data.ignoreLocality = True
config.Data.outLFNDirBase = '/store/user/yeo/'
config.Data.inputDBS = 'global'
config.Data.splitting = 'FileBased'
config.Data.publication = False
config.Data.unitsPerJob = 1
config.section_('Site')
config.Site.storageSite = 'T3_KR_KNU'
config.Site.whitelist = ['T2_*', 'T3_*']
config.section_('User')
config.section_('Debug')
